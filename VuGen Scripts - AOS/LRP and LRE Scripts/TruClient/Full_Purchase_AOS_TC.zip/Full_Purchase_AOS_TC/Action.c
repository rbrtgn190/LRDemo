//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Action()
{
	truclient_step("1", "Navigate to URL", "snapshot=Action_1.inf");
	truclient_step("3", "Click on element (1)", "snapshot=Action_3.inf");
	truclient_step("5", "Type laptop in Search AdvantageOnlineSho... textbox", "snapshot=Action_5.inf");
	truclient_step("7", "Press key Enter on Search AdvantageOnlineSho... textbox", "snapshot=Action_7.inf");
	truclient_step("9", "Select laptop CATEGORIES TOP RE...H LAPTOP $319.99 from Search AdvantageOnlineSho... listbox", "snapshot=Action_9.inf");
	truclient_step("10", "Click on image (1) image", "snapshot=Action_10.inf");
	truclient_step("11", "Click on ADD TO CART button", "snapshot=Action_11.inf");
	truclient_step("13", "Click on element (2)", "snapshot=Action_13.inf");
	truclient_step("15", "Click on CHECKOUT ($519.99) button", "snapshot=Action_15.inf");
	truclient_step("16", "Click on Username textbox", "snapshot=Action_16.inf");
	truclient_step("17", "Type admin in Username textbox", "snapshot=Action_17.inf");
	truclient_step("18", "Type ***** in Password passwordbox", "snapshot=Action_18.inf");
	truclient_step("19", "Click on LOGIN button", "snapshot=Action_19.inf");
	truclient_step("20", "Click on NEXT button", "snapshot=Action_20.inf");
	truclient_step("22", "Type admin in *SafePay username textbox", "snapshot=Action_22.inf");
	truclient_step("23", "Mouse down on *SafePay password passwordbox", "snapshot=Action_23.inf");
	truclient_step("25", "Type ***** in *SafePay password passwordbox", "snapshot=Action_25.inf");
	truclient_step("26", "Click on PAY NOW button", "snapshot=Action_26.inf");
	truclient_step("27", "Click on Thank you for buying...", "snapshot=Action_27.inf");
	truclient_step("28", "Click on admin link", "snapshot=Action_28.inf");
	truclient_step("29", "Click on Sign out link", "snapshot=Action_29.inf");

	return 0;
}
