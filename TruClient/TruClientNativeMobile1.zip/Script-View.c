//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

vuser_init()
{
	return 0;
}

Action()
{
	lr_start_transaction("Search");
	truclient_step("1", "Set Focus on Search Input", "snapshot=Action_1.inf");
	truclient_step("2", "Set Text bose in Search Input", "snapshot=Action_2.inf");
	truclient_step("3", "Tap on imageViewSearch View", "snapshot=Action_3.inf");
	lr_end_transaction("Search",0);
	truclient_step("4", "Select row 0 section 0 at gridViewProducts Table", "snapshot=Action_4.inf");
	truclient_step("5", "Tap on ADD TO CART Button", "snapshot=Action_5.inf");
	truclient_step("6", "Tap on imageViewBack View", "snapshot=Action_6.inf");
	truclient_step("7", "Tap on imageViewBack View", "snapshot=Action_7.inf");
	truclient_step("8", "Tap on imageViewMenu View", "snapshot=Action_8.inf");
	lr_start_transaction("BackHome");
	truclient_step("9", "Tap on HOME Label", "snapshot=Action_9.inf");
	lr_end_transaction("BackHome",0);

	return 0;
}

vuser_end()
{
	return 0;
}
